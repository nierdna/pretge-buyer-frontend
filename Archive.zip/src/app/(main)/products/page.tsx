import ProductsScreen from '@/screens/Products';

export default function ProductsPage() {
  return <ProductsScreen />;
}
