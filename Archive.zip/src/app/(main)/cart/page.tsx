import CartScreen from '@/screens/Cart';

export default function CartPage() {
  return <CartScreen />;
}
