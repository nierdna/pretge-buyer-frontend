import HomeScreen from '@/screens/Home';

export default function Home() {
  return <HomeScreen />;
}
