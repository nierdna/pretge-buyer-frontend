import FlashSaleScreen from '@/screens/FlashSale';

export default async function FlashSalePage() {
  return <FlashSaleScreen />;
}
